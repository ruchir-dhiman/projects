package main

import (
"fmt"
"strconv"
"time"
"ruchir/lst"
"os"
"hash/fnv"
//"math"
)

type Event int
const (
   COM_EVENT Event = 1 + iota
   ORDER
   AE
)

type C_Msg int
const (
   INIT C_Msg = 1 + iota
   VOTE_REQUEST
   VOTE_COMMIT
   REJECT
   ACCEPT
   VOTE_ABORT
   GLOBAL_ABORT
   GLOBAL_COMMIT
   ACK
   TRANSACTION
   REQUEST
   TOKEN
   DEAD
   CHILL
   CHECK
   RP_CHECK
   CORD_CHECK
   CORD_REPLY
   SP_TOKEN
   AE_REP
   AE_REQ
)

type N_State int
const (
   DEFAULT N_State = 1 + iota
   INITS
   WAIT
   READY
   ABORT
   COMMIT
)

type participant struct{
  pstate N_State
  tid int
  cord int
  tp1 time.Time
  tp2 time.Time
}

type stoken struct{
  gorder int
  sp bool
}
type txn struct {
	cord int
	part1 int
	part2 int
	id int
	t_seq int
}

type message struct {
	send int
        recv int
	mType C_Msg
	eType Event
        t txn
        p int
        tkn token
}

type token struct{
  used []int
  l *lst.List
  gorder int
}

type node struct {
   id int
   state N_State
   local_clk int
   msg_ch chan message
   p1 int
   p2 int
   p1a bool
   p2a bool
   p1acc bool
   p2acc bool
   p1c bool
   p2c bool
   res_count int
   p participant
   tran_count int
   t txn
   list []txn
   mp map[int]txn
   seq []int
   tok token
   t_use bool
   t_used bool
   t_check bool
   lmax int
   max time.Duration
   dead []bool
   alive bool
   commitsetl []txn
   commitl []txn
   createdl []txn
   creatingl []int
   abortl []txn
   sent_to int
   recv_from int
   sp_tok stoken
   fthrough []bool
}
func hash(s string) uint32 {
  h := fnv.New32a()
  h.Write([]byte(s))
  return h.Sum32()
}

func getrand(t int) (int){
    temp:= time.Now().Nanosecond()
    temp = temp%t
    return temp
}

func create_txn(n *node,tranid int)(txn){

    var idtemp int
    if tranid==-1{
      fmt.Println("Creating Transaction",n.id)
      var s1,s2,s string

      s1 = strconv.Itoa(n.id+1)

      n.local_clk = n.local_clk + 1;

      s2 = strconv.Itoa(n.local_clk)

      s = s1 + "0"+s2


      var err error
      if idtemp, err = strconv.Atoi(s); err == nil {
      //fmt.Println("i=",idtemp ,"type:", idtemp,"\n")
      }
      n.creatingl = append(n.creatingl, idtemp)
    } else {
      fmt.Println("Received a backed tran",tranid)
      idtemp = tranid
    }

    temp1 := -1
    temp2 := -1

    for temp1 == -1 || temp1 == n.id || n.dead[temp1] {
        temp1 = getrand(total)
    }

    for temp2 == -1 || temp2 == n.id || temp2 == temp1 || n.dead[temp2]{
        temp2 = getrand(total)
    }

    var n2,n3 node
    n2 = nodeArr[temp1]
    n3 = nodeArr[temp2]

    n.state = INITS
    var p1,p2 node
    p1 = n2//node from hash map acc. to part1
    p2 = n3//node from hashmap acc. to part2

    n.p1 = p1.id
    n.p2 = p2.id

    m1 := message{send:n.id, recv:p1.id, mType:INIT, eType:COM_EVENT}
    m2 := message{send:n.id, recv:p2.id, mType:INIT, eType:COM_EVENT}
    //fmt.Println("sending int to ",p1.id," ",p2.id,"from node",n.id)
    p1.msg_ch <- m1
    p2.msg_ch <- m2
    //fmt.Println("sent int to ",p1.id," ",p2.id,"from node",n.id)

    y := getrand(1000000)

    if n.id%17 == 0 && y > 905000{
      fmt.Println("Cordinator dead",n.id)
    	fmt.Println("Killed in INIT")
      n.alive = false
	    d := time.Duration(9000000) * time.Millisecond
      time.Sleep(d)
    }

    tp1 := time.Now().UTC()
    wait := time.Duration(2000)*time.Millisecond
    for n.res_count!= 2 && wait > time.Since(tp1){
      process_message(n)
    }

    if n.res_count == 2{

    p1 = nodeArr[n.p1]
    p2 = nodeArr[n.p2]
    m3 := message{send:n.id, recv:n.p1, mType:VOTE_REQUEST, eType:COM_EVENT}
    y = getrand(1000000)

    if n.id%17 == 0 && y > 902000{
      fmt.Println("Cordinator dead",n.id)
      fmt.Println("Killed in MID")
      n.alive = false
      d := time.Duration(9000000) * time.Millisecond
      time.Sleep(d)
    }
    m4 := message{send:n.id, recv:n.p2, mType:VOTE_REQUEST, eType:COM_EVENT}

    p1.msg_ch <- m3
    p2.msg_ch <- m4
    //fmt.Println("send VOTE_REQUEST to ",n.p1," ",n.p2,"from node",n.id)

          n.state = WAIT
          n.res_count = 0
          //fmt.Println("node state set to wait id",n.id,"p1:",n.p1,"p2:",n.p2)
          //var t txn
          n.t = txn{cord:n.id, part1:n.p1, part2:n.p2, id:idtemp}
          fmt.Println("Transaction created",n.t.id)
          n.createdl = append(n.createdl, n.t)


          // for n.res_count!= 2 {

          //   process_message(n)
          // }

          tp1 := time.Now().UTC()
          wait := time.Duration(1250)*time.Millisecond
          for n.res_count!= 2 && wait > time.Since(tp1){
            process_message(n)
          }

    y = getrand(1000000)
		if n.id%19 == 0 && y > 903000{
      fmt.Println("Cordinator dead",n.id)
			fmt.Println("Killed in WAIT")
      n.alive = false
			d := time.Duration(9000000) * time.Millisecond
      			time.Sleep(d)
   		 }
          if n.res_count == 2{

              if n.p1a == true{
                if n.p2a == false{
                  m3 := message{send:n.id, recv:n.p2, mType:GLOBAL_ABORT, eType:COM_EVENT}
                  p := nodeArr[n.p2]
                  p.msg_ch <- m3

                  n.state = ABORT
                  fmt.Println("p1a send Abort for txn",n.t.id)
                  n.abortl = append(n.abortl, n.t)


                }else{
                  fmt.Println("both send Abort for txn",n.t.id)
                  n.abortl = append(n.abortl, n.t)
                  n.state = ABORT
                }
              }else{
                if n.p2a == false{
                  m3 := message{send:n.id, recv:n.p2, mType:GLOBAL_COMMIT, eType:COM_EVENT}
                  p := nodeArr[n.p2]
                  p.msg_ch <- m3

                  m4 := message{send:n.id, recv:n.p1, mType:GLOBAL_COMMIT, eType:COM_EVENT}
                  p1 := nodeArr[n.p1]
                  p1.msg_ch <- m4
                  n.state = COMMIT
                  fmt.Println("node state set to commit id",n.id,"txn:",n.t.id)
                  n.commitsetl = append(n.commitsetl, n.t)

                }else{
                  m3 := message{send:n.id, recv:n.p1, mType:GLOBAL_ABORT, eType:COM_EVENT}
                  p := nodeArr[n.p1]
                  p.msg_ch <- m3
                  n.state = ABORT
                  fmt.Println("p2a send Abort for txn",n.t.id)
                  n.abortl = append(n.abortl, n.t)

                }
              }
          } else if n.res_count == 1{
              if !n.p1a && !n.p1c{
                fmt.Println("vote dead:",n.p1,"at ",n.id)
                n.dead[n.p1] =  true
                //broadcast dead message
                //broadcast_dead(n,n.p1)
                if n.p2a{
					n.state = ABORT
					fmt.Println("send abort:",n.p2,"at ",n.id)
					n.abortl = append(n.abortl, n.t)
                	}else if n.p2c{
                		m4 := message{send:n.id, recv:n.p2, mType:CHILL, eType:COM_EVENT}
                  		p1 := nodeArr[n.p2]
                  		p1.msg_ch <- m4
                  		n.res_count = 0
				        n.p1 = -1
				        n.p2 = -1
				        n.p1a = false
				        n.p2a = false
				        n.p1c = false
				        n.p2c = false
				        n.p1acc = false
				        n.p2acc = false
                		td:=create_txn(n,n.t.id)
                		return td

                	}
              }else if !n.p2a && !n.p2c{
                fmt.Println("vote dead:",n.p2,"at ",n.id)
                n.dead[n.p2] = true
                //broadcast dead message
                //broadcast_dead(n,n.p2)

                if n.p1a{
					n.state = ABORT
					fmt.Println("send abort:",n.p1,"at ",n.id)
					n.abortl = append(n.abortl, n.t)
                	}else if n.p1c{
                		m4 := message{send:n.id, recv:n.p1, mType:CHILL, eType:COM_EVENT}
                  		p1 := nodeArr[n.p1]
                  		p1.msg_ch <- m4
                  		n.res_count = 0
				        n.p1 = -1
				        n.p2 = -1
				        n.p1a = false
				        n.p2a = false
				        n.p1c = false
				        n.p2c = false
				        n.p1acc = false
				        n.p2acc = false
                		td:=create_txn(n,n.t.id)
                		return td

                	}
              }
          }else if n.res_count == 0{
              fmt.Println("vote dead both:",n.p2,"and",n.p1,"at ",n.id)
              n.dead[n.p1] = true
              n.dead[n.p2] = true
              //broadcast_dead(n,n.p1)
              //broadcast_dead(n,n.p2)
              n.res_count = 0
	          n.p1 = -1
	          n.p2 = -1
	          n.p1a = false
	          n.p2a = false
	          n.p1c = false
	          n.p2c = false
	          n.p1acc = false
	          n.p2acc = false
              td:=create_txn(n,n.t.id)
              return td
          }
    }else if n.res_count == 1{

      if n.p1acc{ //p2 is probably dead
        n.dead[n.p2] = true
        fmt.Println(n.p2,"is dead","at ",n.id)
        //broadcast_dead(n,n.p2)
        m4 := message{send:n.id, recv:n.p1, mType:CHILL, eType:COM_EVENT}
        p1 := nodeArr[n.p1]
        p1.msg_ch <- m4
        n.res_count = 0
        n.p1 = -1
        n.p2 = -1
        n.p1a = false
        n.p2a = false
        n.p1c = false
        n.p2c = false
        n.p1acc = false
        n.p2acc = false
        td:=create_txn(n,idtemp)
        return td
        //broadcast dead message to everybody
      }else if n.p2acc{ //p2 is probably dead
        fmt.Println(n.p1,"is dead","at ",n.id)
        n.dead[n.p1] = true
        //broadcast_dead(n,n.p1)
        m4 := message{send:n.id, recv:n.p2, mType:CHILL, eType:COM_EVENT}
        p1 := nodeArr[n.p2]
        p1.msg_ch <- m4
        n.res_count = 0
        n.p1 = -1
        n.p2 = -1
        n.p1a = false
        n.p2a = false
        n.p1c = false
        n.p2c = false
        n.p1acc = false
        n.p2acc = false
        td:=create_txn(n,idtemp)
        return td
        //broadcast dead message to everybody
      }
    }else if n.res_count == 0{
      n.dead[n.p1] = true
      n.dead[n.p2] = true
      fmt.Println(n.p2,"and",n.p1,"is dead","at ",n.id)
      //broadcast_dead(n,n.p1)
      //broadcast_dead(n,n.p2)
      n.res_count = 0
	    n.p1 = -1
	    n.p2 = -1
	    n.p1a = false
	    n.p2a = false
	    n.p1c = false
	    n.p2c = false
	    n.p1acc = false
	    n.p2acc = false
      	td:=create_txn(n,idtemp)
        return td

    }

    if n.state == COMMIT{
      //fmt.Println("inside commit")
      n.seq[n.id]+=1;
      broadcast_request(n)
      //fmt.Println("after commit",n.t.id)
      //n.list = append(n.list, n.t)
      n.commitl = append(n.commitl, n.t)
      fmt.Println("Txn committed",n.t.id,"of node",n.id)

      y = getrand(1000000)
     if n.id == 19{
     ///fmt.Println("")
     fmt.Println("Killed in TOKEN WAIT",n.id)
     n.alive = false
     //pm(n)
     d := time.Duration(9000000) * time.Millisecond
        time.Sleep(d)
     }

      tp1 := time.Now()
      wait := time.Duration(120000)*time.Millisecond
      for !n.t_use {

        //fmt.Println("waiting for token",n.id)
        process_message(n)
        if wait < time.Since(tp1){

          end := true
          fmt.Println("EXPIRED",n.id)
	      	z := n
          // condit := -1
          // run := 0
          
          clear_fthrough(n)

	      	for end{
            process_message(n)
            //process_message(z)

            if n.t_use {
              break
            }
            if n.fthrough[z.id] {
                fmt.Println("encountered LOOP at ",n.id, " going to backup case (MAKE IT)")
                //break

            }
            // fmt.Println("THE LOOP: run ",run,"condit: ",condit)
            // fmt.Println("THE var z, rcvf ",z.recv_from,", zsntto ",z.sent_to," zid ",z.id)
	      		if z.alive {
              fmt.Fprintf(os.Stderr, "ALIVE AT: %d n.id %d \n", z.id,n.id)
              if z.t_use {
                  end = false
              } else {
                  if z.recv_from == -1 && !z.t_use{
                    g:= z.sent_to
                    z = &nodeArr[g]
                  }else if z.recv_from > (-1)  && !z.t_use{
                    g:=z.recv_from
                    z = &nodeArr[g]
                }
              }
            }else if !z.alive{
              fmt.Fprintf(os.Stderr, "DEAD AT: %d z.recv_from %d z.t_use %d n.id %d\n", z.id,z.recv_from,z.t_use,n.id)
              pm(z)
	      			if z.t_use {
                  end = false
              } else {
                  if z.recv_from == -1 && !z.t_use{
                    g:= z.sent_to
                    z = &nodeArr[g]
                  }else if z.recv_from > (-1)  && !z.t_use{
                    g:=z.recv_from
                    z = &nodeArr[g]
                }
              } 

	      		}else{
              fmt.Println("hai ni chalra bhai... socho isme kya daalna hai")
            }
            n.fthrough[z.id] = true
	      	}
          fmt.Println("outside that looooooooooooooooooooooooop")

          if !end {
            fmt.Println("handle kro bhaiya")
          }

          if n.t_use {
            continue
          }
      		if !z.alive {
      	     fwd_special_token(z,n)
             tp1 = time.Now()
          } else if z.alive{
            tp1 = time.Now()
          }

        }
      }


      // tp2 = time.Since(tp1)
      // if tp2 > n.max{
      //   n.max = tp2
      // }
      fmt.Println("nid: ",n.id,"got token :",n.tok)
      n.tok.gorder += 1

      n.tok.used[n.id]++

      n.t.t_seq = n.tok.gorder
      fmt.Println("nid :",n.id," tid:", n.t.id,"gorder :",n.tok.gorder)
      broadcast_txn(n,n.t)
      fmt.Println("nid :",n.id," tid:", n.t.id,"broadcast gorder :",n.tok.gorder)
      if n.tok.gorder == (n.lmax+1){

        n.list = append(n.list,n.t)
        n.lmax++
        flag:= true
        for flag{
          v, ok := n.mp[n.lmax]
          if ok {
            n.list = append(n.list,v)
            delete (n.mp,n.lmax)
            n.lmax++
          }else{
            flag = false
          }
        }
      } else {
     	if n.tok.gorder > n.lmax{
     	
        n.mp[n.tok.gorder] = n.t
        }

      }
      //n.list = append(n.list, n.t)
      fmt.Println("Txn braodcasted",n.t.id,"of node",n.id)
      if n.id%13 == 0{
        fmt.Println("TDEAD ",n.id)
        n.alive = false
        pm(n)
        d := time.Duration(900000) * time.Millisecond
        time.Sleep(d)
      }
      n.t_used = true
      n.state = DEFAULT
      fwd_token(n)
    }else if n.state == ABORT{
      n.state = DEFAULT
    }else{
          fmt.Println("Panic cordinator final state")
    }
    return n.t
}

func clear_fthrough(n *node) {
  for i:=0;i<total;i++ {
    n.fthrough[i]=false
  }
}

func pm(n *node) {
    l := len(n.msg_ch)
    for i:=0;i<l;i++ {
      select{
        case m:= <- n.msg_ch:
          if m.mType == TOKEN {
            n.t_use = true
            n.tok = m.tkn
          }
        default:
          fmt.Println("no message")
          break
          
        }
    }
}

func fwd_token(n *node){
	//fmt.Println("checking to FWD TOKEN",n.id,"seq:",n.seq)
  //n.tok.used[n.id]++
  n.tok.l = lst.New()
  for i:=(n.id+1);i<total;i++{
    if n.seq[i] == (n.tok.used[i]+1){
      n.tok.l.PushBack(i)
    }
  }
  for i:=0;i<n.id;i++{
    if n.seq[i] == (n.tok.used[i]+1){
      n.tok.l.PushBack(i)
    }
  }

  r := n.tok.l.Front()
  if r != nil{
    n.tok.l.Remove(r)
    r1 := int(r.Value)
    if n.dead[r1]{
    	n.seq[r1] = 0
    	//fwd_token(n)
    	return
    }

	  m3 := message{send:n.id, recv:r1, mType:CHECK, eType:ORDER, tkn:n.tok}
    p := nodeArr[r1]
    p.msg_ch <- m3
    n.t_check = false
    tp1 := time.Now().UTC()
    wait := time.Duration(900)*time.Millisecond
    for !n.t_check && wait > time.Since(tp1){
      process_message(n)
    }
    if n.t_check{
    	    n.t_use = false
          m3 = message{send:n.id, recv:r1, mType:TOKEN, eType:ORDER, tkn:n.tok}
          p = nodeArr[r1]
          p.msg_ch <- m3
          n.sent_to = r1
          n.recv_from = -1
          fmt.Println("TOKEN FWD to",r1,"from",n.id)
    }else{
      n.dead[r1] = true
    	fmt.Println("TOKEN NOT FWD from",n.id)
    	return
    }

  }

}


func fwd_special_token(n,n1 *node ){
  fmt.Println("checking to FWD SP TOKEN",n.id,"seq:",n.seq)
  //n.tok.used[n.id]++
  // n.tok.l = lst.New()
  // for i:=(n.id+1);i<total;i++{
  //   if n.seq[i] == (n.tok.used[i]+1){
  //     n.tok.l.PushBack(i)
  //   }
  // }
  // for i:=0;i<n.id;i++{
  //   if n.seq[i] == (n.tok.used[i]+1){
  //     n.tok.l.PushBack(i)
  //   }
  // }

  // r := n.tok.l.Front()
  // if r != nil{
    
  //   n.tok.l.Remove(r)
  //   r1 := int(r.Value)
  //   if n.dead[r1]{
  //     n.seq[r1]=0
  //     fwd_special_token(n,n1)
  //     return
  //   }

  //   m3 := message{send:n1.id, recv:r1, mType:CHECK, eType:ORDER, tkn:n.tok}
  //   p := nodeArr[r1]
  //   p.msg_ch <- m3
  //   n1.t_check = false
  //   tp1 := time.Now().UTC()
  //   wait := time.Duration(900)*time.Millisecond
  //   for !n1.t_check && wait > time.Since(tp1){
  //     process_message(n1)
  //   }
  //   if n1.t_check{
  //         n.t_use = false
  //         m3 = message{send:n1.id, recv:r1, mType:SP_TOKEN, eType:ORDER, tkn:n.tok}
  //         p = nodeArr[r1]
  //         p.msg_ch <- m3
  //         //n.sent_to = r1
  //         //n.recv_from = -1
  //         fmt.Println("SP TOKEN FWD to",r1,"from",n1.id)
  //   }else{
  //     n.seq[r1]=0
  //     fwd_special_token(n,n1)
  //     //fmt.Println("SP TOKEN NOT FWD from",n1.id)
  //     return
  //   }

  // }else{
          fmt.Println("SP TOKEN NIL")
          n.t_use = false
          m3 := message{send:n1.id, recv:1, mType:SP_TOKEN, eType:ORDER, tkn:n.tok}
          p := nodeArr[1]
          p.msg_ch <- m3
          //n.sent_to = r1
          //n.recv_from = -1
          fmt.Println("SP TOKEN FWD to 1 DUE TO NIL from",n1.id)
            
  //}

}
func broadcast_txn(n *node, tr txn){
  for i:=0;i<total;i++{
    if n.id != i && !n.dead[i]{
      m := message{send:n.id, recv:i, mType:TRANSACTION, eType:ORDER, t:tr, p:tr.t_seq, tkn:n.tok}
      p := nodeArr[i]
      p.msg_ch <- m
    }
    if i==total/3 && n.id%31 == 0{
    	fmt.Println("SYNCHRONY KILL",n.id)
     	n.alive = false
     	d := time.Duration(9000000) * time.Millisecond
        time.Sleep(d)
    }
  }
}


func broadcast_request(n *node){
  for i:=0;i<total;i++{
    if n.id != i && !n.dead[i]{
      m := message{send:n.id, recv:i, mType:REQUEST, eType:ORDER, p:n.seq[n.id]}
      p := nodeArr[i]
      p.msg_ch <- m
    }
  }
}
func broadcast_dead(n *node,p int){
  for i:=0;i<total;i++{
    if n.id != i && !n.dead[i]{
      m := message{send:n.id, recv:i, mType:DEAD, eType:COM_EVENT, p:p}
      p := nodeArr[i]
      p.msg_ch <- m
    }
  }
}

func anti_entropy(n *node){
  if total > 75{
    fwd_ae_req(n)
  } else{
    broadcast_ae_req(n)
  }
  
}

func broadcast_ae_req(n *node){
	fmt.Println("AE_REQ from:",n.id,"for",n.lmax)
  for i:=0;i<total;i++{
    if n.id != i && !n.dead[i]{
      m := message{send:n.id, recv:i, mType:AE_REQ, eType:AE, p:(n.lmax+1)}
          p := nodeArr[i]
          p.msg_ch <- m
    } 
  }
}
func fwd_ae_req(n *node){
  
  for i:=n.id/10;i< total;i+=10{
    if n.id != i && !n.dead[i]{
      m := message{send:n.id, recv:i, mType:AE_REQ, eType:AE, p:(n.lmax+1) }
          p := nodeArr[i]
          p.msg_ch <- m
    } 

  }
}

func start_node(n *node){
  //fmt.Println("start node",n.id)
  t := make(chan message, 3500)
  n.msg_ch = t
  n.alive = true
  if n.id ==1{
    n.t_use = true
    n.t_check = true
  }
  n.tok.l = lst.New()
  n.list = []txn{}
  n.createdl = []txn{}
  n.creatingl = []int{}
  n.commitl = []txn{}
  n.commitsetl = []txn{}
  n.abortl = []txn{}
  n.dead = make([]bool,total)
  n.tok.used = make([]int,total)
  n.seq = make([]int,total)
  n.mp = make(map[int]txn)
  n.fthrough = make([]bool,total)

  //n.mp = make(map[int]txn)
  d := time.Duration(100) * time.Millisecond
      time.Sleep(d)
  prob := 400005
  for {
      //fmt.Printf("gr")
      temp:=getrand(1000000)
      //fmt.Println(temp," ",n.state," ",n.tran_count)
      if temp<400000 && n.tran_count <= 4 && n.state == DEFAULT{
        if n.id %8 == 0{
          prob = 500000
        }else{
          prob +=5
        }
        var tran txn
        n.res_count = 0
        n.p1 = -1
        n.p2 = -1
        n.p1a = false
        n.p2a = false
        n.p1c = false
        n.p2c = false
        n.p1acc = false
        n.p2acc = false
        n.tran_count+=1
        tran = create_txn(n,-1)
        d := time.Duration(5) * time.Millisecond
        time.Sleep(d)
        process_message(n)
        fmt.Println("hello, node",tran.cord,tran.part1,tran.part2,tran.id)
      }else if n.id%8==0 && prob==500000{
          fmt.Println("Node Killed",n.id)
          n.alive = false
         //  for {
         //  	if n.t_use{
         //  		process_message(n)
        	// 	fwd_token(n)
      		 // }else{
      			// break
      		 // }
         //  }
          d := time.Duration(900000) * time.Millisecond
          time.Sleep(d)
      } else{
        //fmt.Println("callin process_message in start_node",n.id)
        process_message(n)
        //fmt.Println("sleeping ",n.id)
        // d := time.Duration(1) * time.Millisecond
        // time.Sleep(d)
        process_message(n)
        process_message(n)
      }
      if n.t_use{
        fwd_token(n)
      }
  }

}

func process_message(n *node){
  wait := time.Duration(5000)*time.Millisecond
  if n.p.pstate == INITS && wait < time.Since(n.p.tp1){
        n.p.pstate = DEFAULT
        n.dead[n.p.cord] = true
        fmt.Println("Participant TIMEDOUT INITS for cord",n.p.cord,"at",n.id)
  } else if n.p.pstate == READY && wait < time.Since(n.p.tp2){
        n.p.pstate = DEFAULT
        n.dead[n.p.cord] = true
        fmt.Println("Participant TIMEDOUT READY for cord",n.p.cord,"at",n.id)
  }



  var m message
  select{
    case m = <- n.msg_ch:
          switch(m.mType){
            case AE_REQ:
                //fmt.Println("pmm AE_REQ :",n.id,"from",m.send,"for",m.p) 
                if n.lmax >= m.p {
                  tt := n.list[m.p-1]
                  if tt.t_seq == m.p{
                    
                        m1 := message{send:n.id, recv:m.send, mType:AE_REP, eType:AE, t:n.list[m.p-1], p:m.p}
                        p := nodeArr[m.send]
                        p.msg_ch <- m1
                  } else{
                  //  fmt.Println("Panic in AE_REQ")
                  }
                }

            case AE_REP:
                  //fmt.Println("pmm AE_REP :",n.id,"from",m.send,"for",m.p,"tran:",m.t,"lmax",n.lmax) 
                  if m.t.t_seq == (n.lmax+1){
                    //fmt.Println("AE_REP USED for ",m.p ,"at",n.id)
                    //n.list = append(n.list,m.t)
                    
                    //n.lmax++
                    n.mp[m.p] = m.t
                    flag:= true
                    	for flag{
                    		v, ok := n.mp[n.lmax+1]
                    		if ok {
                        		n.list = append(n.list,v)
                      //  		fmt.Println("AE_REP MAP",v,"at",n.id)
                                        //n.recv_from = m.send
                          		delete (n.mp,n.lmax+1)
                          		n.lmax++
                        	}else{
                          		flag = false
                        	}
                      	}

                  } else {
                    //fmt.Println("AE_REP NOTUSED for ",m.p ,"at",n.id)
                  }

            case SP_TOKEN:
                //fmt.Println("pmm SP_TOKEN",n.id," by ",m.send," token: ",m.tkn)
                if n.sp_tok.gorder < m.tkn.gorder {
                  n.sp_tok.gorder = m.tkn.gorder
                  n.t_use = true
                  n.t_used = false
                  n.tok = m.tkn
                  //n.sp_tok.sp = true

                }

            case CHECK:
            		//fmt.Println("pmm CHECK",n.id," by ",m.send," token: ",m.tkn)
            		m1 := message{send:n.id, recv:m.send, mType:RP_CHECK, eType:COM_EVENT}
                p := nodeArr[m.send]
                p.msg_ch <- m1
            case RP_CHECK:
            	  //fmt.Println("pmm RP_CHECK",n.id," by ",m.send," token: ",m.tkn)
            	  n.t_check = true

            case TOKEN:
                 // fmt.Println("pmm TOKEN",n.id," by ",m.send," token: ",m.tkn)
                  n.tok = m.tkn
                  n.t_use = true
                  n.t_used = false

                 // fmt.Println("processed token",n.id,"use:",n.t_use)

            case REQUEST:
                   // fmt.Println("pmm REQUEST",n.id," by ",m.send," value: ",m.p)
                    n.seq[m.send] = m.p
                   // fmt.Println("nid:",n.id," seq:",n.seq)
                    if n.t_use && n.t_used && n.t_check {
                      fwd_token(n)
                    }
            case CHILL:
                //fmt.Println("pmm CHILL",n.id," by ",m.send)
                if n.p.pstate == READY || n.p.pstate == INITS{
                  n.p.pstate = DEFAULT
                  } else {
                    //fmt.Println("Panic participant state change",n.p.pstate)
                  }

            case DEAD:
                    //fmt.Println("pmm DAAD",n.id," by ",m.send," value: ",m.p)
                    n.dead[m.p] = true
            case TRANSACTION:
                    //fmt.Println("pmm TRANSACTION",n.id," by ",m.send," value: ",m.t.id)
                if n.tok.gorder < m.tkn.gorder{
                  n.tok = m.tkn
                  n.recv_from = m.send
                }

		        if m.p == (n.lmax+1){
                    	n.list = append(n.list,m.t)
                    	//fmt.Println("TRANSACTION LIST",m.t,"at",n.id)
                        //n.recv_from = m.send
                    	n.lmax++
                    	flag:= true
                    	for flag{
                    		v, ok := n.mp[n.lmax]
                    		if ok {
                        		n.list = append(n.list,v)
                        //		fmt.Println("TRANSACTION MAP",v,"at",n.id)
                              n.recv_from = m.send
                          		delete (n.mp,n.lmax)
                          		n.lmax++
                        	}else{
                          		flag = false
                        	}
                      	}
                    } else {
                        if m.t.t_seq > n.lmax{
                           n.mp[m.p] = m.t
                        }
                    	

                      if m.p > (n.lmax + 4){
                        anti_entropy(n)
                      }

                    }
                    //n.list = append(n.list,m.t)
            case INIT:
                    //fmt.Println("pmm init",n.id," by ",m.send)
                    if n.p.pstate != DEFAULT{
                      var m1 message
                      m1 = message{send:n.id, recv:m.send, mType:REJECT, eType:COM_EVENT}
                      var r node
                      r = nodeArr[m.send]
                      r.msg_ch <- m1
                      //fmt.Println("RJ TO ",m.send)
                    } else{
                      n.p.pstate = INITS
                      n.p.tp1 = time.Now()
                      n.p.cord = m.send
                      var m1 message
                      m1 = message{send:n.id, recv:m.send, mType:ACCEPT, eType:COM_EVENT}
                      var r node
                      r = nodeArr[m.send]
                      r.msg_ch <- m1

                    }
            case REJECT:
              //fmt.Println("pmm reject",n.id," from ",m.send)
                      //fmt.Println("Got reject from participant")
                      temp := -1

                      if m.send == n.p1{
                        for temp == -1 || temp == m.send || temp == n.p2 || temp == n.id || n.dead[temp]{
                          temp = getrand(total)
                        }
                        n.p1 = temp
                        m1 := message{send:n.id, recv:temp, mType:INIT, eType:COM_EVENT}
                        p := nodeArr[temp]
                        p.msg_ch <- m1
                      } else if m.send == n.p2{
                        for temp == -1 || temp == m.send || temp == n.p1 || temp == n.id || n.dead[temp]{
                          temp = getrand(total)
                        }
                        n.p2 = temp
                        m1 := message{send:n.id, recv:temp, mType:INIT, eType:COM_EVENT}
                        p := nodeArr[temp]
                        p.msg_ch <- m1
                      }else{
                        fmt.Println("Panic value not getting updated correctly REJECT sender:",m.send,"p1:",n.p1,"p2:",n.p2)
                      }




            case ACCEPT:
                      //fmt.Println("pmm ACCEPT",n.id," from ",m.send)
                      n.res_count = n.res_count + 1
                      if m.send == n.p1{
                        n.p1acc = true
                      } else if m.send == n.p2{
                        n.p2acc = true
                      }
                      // if n.res_count == 1{
                      //   n.p1 = m.send
                      // }else if n.res_count == 2{
                      //   n.p2 = m.send
                      // }
            case VOTE_REQUEST:
              //fmt.Println("pmm VOTE_REQUEST",n.id," from ",m.send)
                      //n.p.tp1 = 0
                      n.p.tp2 = time.Now()
                      temp := getrand(100)
                      if temp < 80{
                        m1 := message{send:n.id, recv:m.send, mType:VOTE_COMMIT, eType:COM_EVENT}
                        p := nodeArr[m.send]
                        p.msg_ch <- m1
                        n.p.pstate = READY
                      }else{
                        m1 := message{send:n.id, recv:m.send, mType:VOTE_ABORT, eType:COM_EVENT}
                        p := nodeArr[m.send]
                        p.msg_ch <- m1
                        n.p.pstate = DEFAULT
                      }
            case VOTE_ABORT:
              //fmt.Println("pmm VOTE_ABORT",n.id," by ",m.send)
                      n.state = ABORT
                      n.res_count++;
                      if m.send == n.p1{
                        n.p1a = true
                      }else if m.send == n.p2{
                        n.p2a = true
                      }else{
                        fmt.Println("Panic vote abort",m.send,"p1:",n.p1,"p2:",n.p2)
                      }

            case VOTE_COMMIT:
                      //fmt.Println("pmm VOTE_COMMIT",n.id," by ",m.send)
                      n.res_count++;
                      if m.send == n.p1{
                        n.p1c = true
                      }else if m.send == n.p2{
                        n.p2c = true
                      }

            case GLOBAL_ABORT:
              //fmt.Println("pmm GLOBAL_ABORT",n.id)
                      if n.p.pstate == READY{
                        n.p.pstate = DEFAULT
                      }else{
                        fmt.Println("Panic global abort",m.send,"p1:",n.p1,"p2:",n.p2)
                      }

            case GLOBAL_COMMIT:
              //fmt.Println("pmm GLOBAL_COMMIT",n.id)
                      if n.p.pstate == READY{
                        n.p.pstate = DEFAULT
                      }else{
                        fmt.Println("Panic global commit",m.send,"p1:",n.p1,"p2:",n.p2)
                      }

          }
    default:
      //fmt.Println("no message")
    }
    d := time.Duration(500) * time.Nanosecond
    time.Sleep(d)
}

var nodeArr []node
var total int
var cord int

func main() {

      //fmt.Printf("hello, world\n")
      fmt.Scan(&total)

      nodeArr = make([]node,total)

      for i:=0;i<total;i++{
        nodeArr[i] = node{id:i ,state:DEFAULT,p:participant{pstate:DEFAULT},local_clk:0}
      }
      for i:=0;i<total;i++{
        fmt.Println(nodeArr[i].id, nodeArr[i].state)
      }

      for i:=0;i<total;i++{
        go start_node(&nodeArr[i])
      }

      fmt.Println("done1")

      d := time.Duration(600000) * time.Millisecond
      time.Sleep(d)

      // for i:=0;i<total;i++{
      //   fmt.Println("node :",nodeArr[i].id," creaaaaating : ",nodeArr[i].creatingl)
      //   fmt.Println("node :",nodeArr[i].id," creaaaaated : ",nodeArr[i].createdl)
      //   fmt.Println("node :",nodeArr[i].id," commitset : ",nodeArr[i].commitsetl)
      //   fmt.Println("node :",nodeArr[i].id," commited : ",nodeArr[i].commitl)
      //   fmt.Println("node :",nodeArr[i].id," abort : ",nodeArr[i].abortl)
      //   fmt.Println("\n")

      // }
      l := len(nodeArr[1].list)
      broadcast_txn(&nodeArr[1],nodeArr[1].list[l-1])

        d = time.Duration(60000) * time.Millisecond
      time.Sleep(d)

      for i:=0;i<total;i++{
        fmt.Println("node :",nodeArr[i].id," list : ",nodeArr[i].list)
        fmt.Println("node :",nodeArr[i].id," map : ",nodeArr[i].mp)
        fmt.Println("node :",nodeArr[i].id," lmax : ",nodeArr[i].lmax)
        fmt.Println("node :",nodeArr[i].id," t_use : ",nodeArr[i].t_use)
        
        //fmt.Println("node :",nodeArr[i].id," recv_from : ",nodeArr[i].recv_from)
        fmt.Println("\n")

      }

      for i:=0;i<total;i++{
          var s string
          for j:=0;j<len(nodeArr[i].list);j++{
            s += fmt.Sprintf("%[1]d ",nodeArr[i].list[j].t_seq)
          }
        //fmt.Println("node ",nodeArr[i].id," ",s)
        fmt.Println("% x", hash(s))
      }


      fmt.Println("done")

}
