<?php
system('python verify.py s.pdf');
?>
